MageStage é um projeto em desenvolvimento para por em prática todo o conhecimento adquirido pelos colaboradores. Este consiste em uma micro rede social designada para devs e toda comunidade de tecnologia no geral!

Até o momento, foi montado o básico do servidor em Node.JS, foi configurada a conexão com o banco de dados (mySQL) utilizando a ORM Sequelize, e foram criados alguns modelos e instâncias do banco de dados.
Sinta-se a vontade caso queira fazer parte deste projeto :D. 

Tecnologias utilizadas:

Node.JS / Express.JS
mySQL / Sequelize
bcrypt
nodemon
